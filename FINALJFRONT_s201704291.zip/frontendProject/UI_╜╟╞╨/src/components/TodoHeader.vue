<template>
  
    <div class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                    <li class="list">1</li>
                    <li class="list">2</li>
                    <li class="list">3</li>
                    <li class="list">4</li>

                </ul>
            </div>
        </div>
    </div>
  
</template>

<script>
  export default {
      
  }
</script>

<style>
  li.list {
    margin-top: 5px;
  }
</style>