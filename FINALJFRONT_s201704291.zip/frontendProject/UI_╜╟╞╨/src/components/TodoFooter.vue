<template>
        <footer>
            <p>&copy; UI기말</p>
        </footer>
 
</template>

<script>
  export default {

  }
</script>

<style>
  
</style>