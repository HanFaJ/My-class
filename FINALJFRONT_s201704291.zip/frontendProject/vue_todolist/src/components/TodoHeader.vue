<template>
    <header>
      <h1>TODO lt!</h1>
    </header>
</template>

<script>
  export default {
      
  }
</script>

<style>
  h1 {
    color: #2f3b52;
    font-weight: 900;
    margin: 2.5rem 0 1.5rem;
  }

</style>